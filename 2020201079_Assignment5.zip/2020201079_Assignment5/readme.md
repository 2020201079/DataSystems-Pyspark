How to run the file

python3 pyspark_3.py <Number of CPU> <output file name> 

example:
python3 pyspark_1.py 4 out1.txt
python3 pyspark_2.py 4 out2.txt 
python3 pyspark_3.py 4 out3.txt  

make sure that airport.csv file is present in the same folder